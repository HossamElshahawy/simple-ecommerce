@extends('dash::app')
@section('content')
<div class="row">
    {!! $content !!}
</div>
@endsection
