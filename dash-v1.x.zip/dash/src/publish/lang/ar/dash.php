<?php
return [
	'users' => 'المستخدمين',
	'admin_groups' => 'مجموعات المشرفين',
	'admin_group_roles' => 'صلاحيات المجموعات',
];